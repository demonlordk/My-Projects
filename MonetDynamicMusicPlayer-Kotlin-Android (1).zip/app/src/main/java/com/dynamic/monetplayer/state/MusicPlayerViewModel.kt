package com.dynamic.monetplayer.state

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dynamic.monetplayer.data.MusicAiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtUrl: String?,
    val uri: String
)

class MusicPlayerViewModel(private val aiRepo: MusicAiRepository) : ViewModel() {
    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong

    private val _currentBitmap = MutableStateFlow<Bitmap?>(null)
    val currentBitmap: StateFlow<Bitmap?> = _currentBitmap

    private val _favorites = MutableStateFlow<Set<Long>>(emptySet())
    val favorites: StateFlow<Set<Long>> = _favorites

    private val _lyrics = MutableStateFlow("Loading lyrics...")
    val lyrics: StateFlow<String> = _lyrics

    fun toggleFavorite(songId: Long) {
        _favorites.value = if (_favorites.value.contains(songId)) {
            _favorites.value - songId
        } else {
            _favorites.value + songId
        }
    }

    fun loadTrack(song: Song, coverBitmap: Bitmap?) {
        _currentSong.value = song
        _currentBitmap.value = coverBitmap
        viewModelScope.launch {
            val res = aiRepo.fetchLyrics(song.title, song.artist)
            _lyrics.value = res?.syncedLyrics ?: res?.plainLyrics ?: "No lyrics found."
        }
    }
}
