package com.dynamic.monetplayer.theme

import android.graphics.Bitmap
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.palette.graphics.Palette

object DynamicPaletteEngine {
    fun extractColorScheme(bitmap: Bitmap?): ColorScheme {
        if (bitmap == null) {
            return darkColorScheme(
                primary = Color(0xFF8B5CF6),
                secondary = Color(0xFF06B6D4),
                surface = Color(0xFF1E1B2E),
                background = Color(0xFF13111C)
            )
        }

        val palette = Palette.from(bitmap).generate()
        val dominant = palette.dominantSwatch?.rgb?.let { Color(it) } ?: Color(0xFF1E1B2E)
        val vibrant = palette.vibrantSwatch?.rgb?.let { Color(it) } ?: dominant
        val muted = palette.mutedSwatch?.rgb?.let { Color(it) } ?: Color(0xFF313244)

        return darkColorScheme(
            primary = vibrant,
            onPrimary = Color.White,
            primaryContainer = muted,
            onPrimaryContainer = Color.White,
            surface = dominant.copy(alpha = 0.35f),
            background = Color(0xFF11111B),
            onBackground = Color(0xFFCDD6F4),
            onSurface = Color(0xFFBAC2DE)
        )
    }
}
