package com.dynamic.monetplayer.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Body

data class LrcResponse(
    val plainLyrics: String?,
    val syncedLyrics: String?
)

interface LyricsApi {
    @GET("api/get")
    suspend fun getLyrics(
        @Query("track_name") track: String,
        @Query("artist_name") artist: String
    ): LrcResponse
}

data class AiPromptRequest(val contents: List<Content>)
data class Content(val parts: List<Part>)
data class Part(val text: String)
data class AiResponse(val candidates: List<Candidate>?)
data class Candidate(val content: Content?)

interface GeminiAiApi {
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateInsights(
        @Query("key") apiKey: String,
        @Body request: AiPromptRequest
    ): AiResponse
}

class MusicAiRepository(private val apiKey: String) {
    private val lyricsApi = Retrofit.Builder()
        .baseUrl("https://lrclib.net/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(LyricsApi::class.java)

    suspend fun fetchLyrics(track: String, artist: String): LrcResponse? {
        return runCatching { lyricsApi.getLyrics(track, artist) }.getOrNull()
    }
}
