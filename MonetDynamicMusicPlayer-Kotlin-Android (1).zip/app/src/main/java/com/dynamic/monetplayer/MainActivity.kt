package com.dynamic.monetplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dynamic.monetplayer.data.MusicAiRepository
import com.dynamic.monetplayer.state.MusicPlayerViewModel
import com.dynamic.monetplayer.state.Song
import com.dynamic.monetplayer.ui.NowPlayingScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val aiRepo = MusicAiRepository(apiKey = "YOUR_GEMINI_API_KEY")

        setContent {
            val viewModel: MusicPlayerViewModel = viewModel {
                MusicPlayerViewModel(aiRepo).apply {
                    loadTrack(
                        Song(
                            id = 1L,
                            title = "Neon Horizon",
                            artist = "Aetheria",
                            album = "Chasing Stars",
                            albumArtUrl = "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=500",
                            uri = ""
                        ),
                        coverBitmap = null
                    )
                }
            }
            NowPlayingScreen(viewModel = viewModel)
        }
    }
}
