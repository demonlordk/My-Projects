package com.dynamic.monetplayer.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class AudioTagManager(private val context: Context) {
    suspend fun updatePermanentMetadata(
        fileUri: Uri,
        newTitle: String?,
        newArtist: String?,
        newAlbum: String?,
        coverUrl: String?
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val tempFile = File(context.cacheDir, "tag_edit_temp.mp3")
            context.contentResolver.openInputStream(fileUri)?.use { input ->
                FileOutputStream(tempFile).use { input.copyTo(it) }
            }

            val audioFile = AudioFileIO.read(tempFile)
            val tag = audioFile.tagOrCreateAndSetDefault

            newTitle?.let { tag.setField(FieldKey.TITLE, it) }
            newArtist?.let { tag.setField(FieldKey.ARTIST, it) }
            newAlbum?.let { tag.setField(FieldKey.ALBUM, it) }

            if (!coverUrl.isNullOrEmpty()) {
                val imageBytes = URL(coverUrl).readBytes()
                val tempCover = File(context.cacheDir, "cover_temp.jpg").apply {
                    writeBytes(imageBytes)
                }
                val artwork = ArtworkFactory.createArtworkFromFile(tempCover)
                tag.deleteArtworkField()
                tag.setField(artwork)
            }

            audioFile.commit()

            context.contentResolver.openOutputStream(fileUri, "wt")?.use { output ->
                tempFile.inputStream().use { it.copyTo(output) }
            }
            tempFile.delete()
            true
        }
    }
}
