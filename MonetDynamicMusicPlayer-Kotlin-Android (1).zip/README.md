# Monet Dynamic Music Player (Kotlin + Jetpack Compose)

Material You Dynamic Color Music Player with real-time Palette extraction, AI metadata tagging, and lyrics sync.

### How to Compile APK:

#### Method 1: GitHub Cloud Build (Instant, No Android Studio)
1. Push this folder to a new GitHub repository.
2. Go to **Actions** tab in GitHub.
3. The "Build Dynamic Music Player APK" workflow will trigger.
4. Download the generated `MonetMusicPlayer-Debug-APK` artifact!

#### Method 2: Local Android Studio
1. Open this directory in **Android Studio Hedgehog / Iguana / Ladybug**.
2. Sync Gradle.
3. Run `./gradlew assembleDebug` in the terminal.
4. Find your compiled APK at: `app/build/outputs/apk/debug/app-debug.apk`!
